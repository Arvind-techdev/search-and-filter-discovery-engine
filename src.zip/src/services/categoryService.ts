import { CategoryModel } from "@/models/category";

/**
 * Resolves a category document by abbreviation, slug, or name (case-insensitive).
 * Returns the category document or null if not found.
 */
export async function resolveCategory(input: string): Promise<any | null> {
  if (!input) return null;
  const regex = new RegExp(`^${input}$`, "i");
  // Try abbreviation, slug, or name
  const category = await CategoryModel.findOne({
    $or: [
      { abbreviations: { $regex: regex } },
      { slug: { $regex: regex } },
      { name: { $regex: regex } },
    ],
  }).lean();
  return category;
}
