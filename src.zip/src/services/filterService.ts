import { CategoryModel } from "@/models/category";
import { ProductModel } from "@/models/product";
import { escapeRegex } from "@/utils/searchHelpers";

export const extractUnique = async (field: string, q: string): Promise<string[]> => {
  const qWords = q
    .toLowerCase()
    .split(/\s+/)
    .filter((w) => w.length > 1);
  const regex = new RegExp(qWords.map(escapeRegex).join("|"), "i");
  const category: any = await CategoryModel.findOne({
    abbreviations: { $regex: regex },
  }).lean();
  if (category) {
    const allProductsInCategorys = await ProductModel.find({
      category: category._id,
    }).lean();
    const uniqueValues = [
      ...new Set(
        allProductsInCategorys
          .map((r) => r?.attributes?.[field])
          .filter((v) => v !== undefined && v !== null && v !== "")
      ),
    ];
    return uniqueValues;
  } else {
    return [];
  }
};
