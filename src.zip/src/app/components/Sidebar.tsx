// components/Sidebar.tsx
import React, { useState } from "react";

interface SidebarProps {
  filterOptions: any;
  selectedFilters: any;
  setSelectedFilters: (filters: any) => void;
  onApply: () => void;
}

export default function Sidebar({
  filterOptions,
  selectedFilters,
  setSelectedFilters,
  onApply,
}: SidebarProps) {
  // Controlled price state (min and max)
  const [minPrice, setMinPrice] = useState(
    Array.isArray(selectedFilters.price) ? selectedFilters.price[0] : 0
  );
  const [maxPrice, setMaxPrice] = useState(
    Array.isArray(selectedFilters.price) ? selectedFilters.price[1] : 10000
  );

  // Update selectedFilters.price as [min, max]
  const updatePrice = (min: number, max: number) => {
    setMinPrice(min);
    setMaxPrice(max);
    setSelectedFilters((prev: any) => ({ ...prev, price: [min, max] }));
  };

  // Helper for checkbox change
  const handleCheckbox = (key: string, value: string) => {
    setSelectedFilters((prev: any) => {
      const arr = prev[key] || [];
      return {
        ...prev,
        [key]: arr.includes(value)
          ? arr.filter((v: string) => v !== value)
          : [...arr, value],
      };
    });
  };

  // Helper for single value change
  const handleChange = (key: string, value: string) => {
    setSelectedFilters((prev: any) => ({ ...prev, [key]: value }));
  };


  return (
    <aside
      style={{
        width: 260,
        minWidth: 200,
        maxWidth: 280,
        background: "#fff",
        border: "1px solid #e0e2e6",
        borderRadius: 14,
        boxShadow: "0 2px 8px rgba(0,0,0,0.06)",
        padding: 24,
        marginRight: 32,
        position: "sticky",
        top: 88,
        alignSelf: "flex-start",
        height: "fit-content",
        display: "flex",
        flexDirection: "column",
        gap: 18,
        transition: "box-shadow 0.2s",
      }}
    >
      {/* Categories Dropdown */}
      <label style={{ fontWeight: 600, fontSize: 15, marginBottom: 10 }}>
        Categories
      </label>
      <select
        style={{
          width: "100%",
          padding: 8,
          borderRadius: 6,
          border: "1px solid #e0e2e6",
          marginBottom: 18,
        }}
        value={selectedFilters.category || ""}
        onChange={(e) => handleChange("category", e.target.value)}
      >
        <option value="">All Categories</option>
        {(filterOptions.categories || []).map((cat: string) => (
          <option key={cat} value={cat}>
            {cat}
          </option>
        ))}
      </select>

      {/* Price Range Section */}
<label style={{ fontWeight: 600, fontSize: 15, marginBottom: 10 }}>
  Price Range
</label>
<div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 16 }}>
  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
    <span style={{ color: '#7c3aed', fontWeight: 600, fontSize: 22 }}>
      ${minPrice} - ${maxPrice}
    </span>
  </div>

  {/* Min Price Slider */}
  <label style={{ fontSize: 13, marginBottom: 4 }}>Min Price</label>
  <input
    type="range"
    min={0}
    max={maxPrice - 10}
    step={10}
    value={minPrice}
    onChange={e => {
      const value = Math.min(Number(e.target.value), maxPrice - 10);
      updatePrice(value, maxPrice);
    }}
  />

  {/* Max Price Slider */}
  <label style={{ fontSize: 13, marginBottom: 4, marginTop: 8 }}>Max Price</label>
  <input
    type="range"
    min={minPrice + 10}
    max={10000}
    step={10}
    value={maxPrice}
    onChange={e => {
      const value = Math.max(Number(e.target.value), minPrice + 10);
      updatePrice(minPrice, value);
    }}
  />
</div>


      {/* Attributes Section */}
      <div style={{ marginBottom: 12 }}>
        <div style={{ fontWeight: 600, fontSize: 15, margin: "16px 0 8px 0" }}>
          Attributes
        </div>
        {(filterOptions.sizes?.length ||
          filterOptions.colors?.length ||
          filterOptions.materials?.length ||
          filterOptions.grades?.length) ? (
          <>
            {filterOptions.sizes?.length > 0 && (
              <div>
                <label>
                  <input
                    type="checkbox"
                    checked={(selectedFilters.sizes || []).includes("Size")}
                    onChange={() => handleCheckbox("sizes", "Size")}
                  />{" "}
                  Size
                </label>
              </div>
            )}
            {filterOptions.colors?.length > 0 && (
              <div>
                <label>
                  <input
                    type="checkbox"
                    checked={(selectedFilters.colors || []).includes("Color")}
                    onChange={() => handleCheckbox("colors", "Color")}
                  />{" "}
                  Color
                </label>
              </div>
            )}
            {filterOptions.materials?.length > 0 && (
              <div>
                <label>
                  <input
                    type="checkbox"
                    checked={(selectedFilters.materials || []).includes("Material")}
                    onChange={() => handleCheckbox("materials", "Material")}
                  />{" "}
                  Material
                </label>
              </div>
            )}
            {filterOptions.grades?.length > 0 && (
              <div>
                <label>
                  <input
                    type="checkbox"
                    checked={(selectedFilters.grades || []).includes("Grade")}
                    onChange={() => handleCheckbox("grades", "Grade")}
                  />{" "}
                  Grade
                </label>
              </div>
            )}
          </>
        ) : null}
      </div>

      {/* UK size Section */}
      {filterOptions.sizes?.length > 0 && (
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontWeight: 600, fontSize: 15, margin: "16px 0 8px 0" }}>
            UK size
          </div>
          {(filterOptions.sizes || []).map((size: string) => (
            <div key={size}>
              <label>
                <input
                  type="checkbox"
                  checked={(selectedFilters.sizes || []).includes(size)}
                  onChange={() => handleCheckbox("sizes", size)}
                />{" "}
                {size}
              </label>
            </div>
          ))}
        </div>
      )}

      {/* Brand Section */}
      {filterOptions.brands?.length > 0 && (
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontWeight: 600, fontSize: 15, margin: "16px 0 8px 0" }}>
            Brand
          </div>
          {(filterOptions.brands || []).map((brand: string) => (
            <div key={brand}>
              <label>
                <input
                  type="checkbox"
                  checked={(selectedFilters.brands || []).includes(brand)}
                  onChange={() => handleCheckbox("brands", brand)}
                />{" "}
                {brand}
              </label>
            </div>
          ))}
        </div>
      )}

      {/* Location Input */}
      <label
        htmlFor="location-input"
        style={{ fontWeight: 600, fontSize: 15, marginBottom: 10 }}
      >
        Location
      </label>
      <input
        id="location-input"
        type="text"
        placeholder="Enter location"
        style={{
          width: "100%",
          padding: 8,
          borderRadius: 6,
          border: "1px solid #e0e2e6",
          marginBottom: 18,
        }}
        value={selectedFilters.location || ""}
        onChange={(e) => handleChange("location", e.target.value)}
      />

      {/* Apply Filters Button */}
      <button
        style={{
          background: "#7c3aed",
          color: "#fff",
          border: "none",
          borderRadius: 6,
          fontWeight: 600,
          fontSize: 15,
          padding: "10px 0",
          width: "100%",
          marginTop: 8,
          cursor: "pointer",
          boxShadow: "0 1px 4px rgba(124,58,237,0.09)",
          transition: "background 0.2s",
        }}
        onMouseOver={(e) => (e.currentTarget.style.background = "#5b21b6")}
        onMouseOut={(e) => (e.currentTarget.style.background = "#7c3aed")}
        onClick={onApply}
      >
        Apply Filters
      </button>
    </aside>
  );
}
