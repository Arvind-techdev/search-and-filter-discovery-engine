import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { ProductModel } from "@/models/product";
import { BaseProduct } from "@/types/product";
import { buildSearchQuery } from "@/services/searchService";
import { resolveCategory } from "@/services/categoryService";
import { extractUnique } from "@/services/filterService";

export async function GET(req: NextRequest) {
  const query = req.nextUrl.searchParams.get("q") || "";
  const page = parseInt(req.nextUrl.searchParams.get("page") || "1", 10);
  const limit = parseInt(req.nextUrl.searchParams.get("limit") || "60", 10);
  const skip = (page - 1) * limit;

  const categoryParam = req.nextUrl.searchParams.get("category");
  const filtersParam = req.nextUrl.searchParams.get("filters");
  let filters: Record<string, any> = {};
  let categoryId: string | null = null;

  if (filtersParam) {
    try {
      filters = JSON.parse(filtersParam);
    } catch {
      return NextResponse.json({ error: "Invalid filters JSON" }, { status: 400 });
    }
  }

  if (categoryParam) {
    const categoryDoc = await resolveCategory(categoryParam);
    if (categoryDoc?._id) {
      categoryId = categoryDoc._id.toString();
    }
  }

  await connectDB();

  const queryObj = await buildSearchQuery(query, filters, categoryId ? [categoryId] : []);
  const [rawResults, totalCount] = await Promise.all([
    ProductModel.find(queryObj).skip(skip).limit(limit).lean<BaseProduct[]>(),
    ProductModel.countDocuments(queryObj),
  ]);

  const seenIds = new Set();
  // Enrich products with category data
  const results = await Promise.all(
    rawResults.filter((doc) => {
      const idStr = doc._id?.toString();
      if (!idStr) return false;
      if (seenIds.has(idStr)) return false;
      seenIds.add(idStr);
      return true;
    }).map(async (product) => {
      let categoryData = null;
      if (product.category) {
        categoryData = await (await import("@/models/category")).CategoryModel.findById(product.category).lean();
      }
      return { ...product, categoryData };
    })
  );

  const filtersForUI = {
    brands: await extractUnique("brand", query),
    locations: await extractUnique("location", query),
    colors: await extractUnique("color", query),
    sizes: await extractUnique("size", query),
    types: await extractUnique("type", query),
    categories: await extractUnique("category", query),
    npks: await extractUnique("npk", query),
    use_cases: await extractUnique("useCase", query),
    materials: await extractUnique("material", query),
    genders: await extractUnique("gender", query),
    screen_sizes: await extractUnique("screen_size", query),
    resolutions: await extractUnique("resolution", query),
    technologies: await extractUnique("technology", query),
    packaging: await extractUnique("packaging", query),
  };

  return NextResponse.json({
    filters: filtersForUI,
    results,
    totalCount,
    page,
    limit,
  });
}